<?php
$servername = "localhost";
$username = "root";
$password = "@Sumeet9075";
$dbname = "farmfresh";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("❌ Connection failed: " . $conn->connect_error);
}

$loginMessage = "";
$showLogin = false;

// Handle registration
if (isset($_POST['sb'])) {
    $name = $conn->real_escape_string(trim($_POST['user_name']));
    $email = $conn->real_escape_string(trim($_POST['user_email']));
    $pass = $_POST['user_pass'];
    $repass = $_POST['user_repass'];

    if (empty($name) || empty($email) || empty($pass) || empty($repass)) {
        echo "<script>alert('❌ Please fill all the required fields.'); window.history.back();</script>";
        exit();
    }

    if ($pass !== $repass) {
        echo "<script>alert('❌ Passwords do not match.'); window.history.back();</script>";
        exit();
    }

    $checkQuery = "SELECT id FROM users WHERE email = ?";
    $checkStmt = $conn->prepare($checkQuery);
    $checkStmt->bind_param("s", $email);
    $checkStmt->execute();
    $checkStmt->store_result();

    if ($checkStmt->num_rows > 0) {
        echo "<script>alert('❌ This email is already registered.'); window.history.back();</script>";
        $checkStmt->close();
        $conn->close();
        exit();
    }
    $checkStmt->close();

    $hashed_pass = password_hash($pass, PASSWORD_DEFAULT);

    $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $email, $hashed_pass);

    if ($stmt->execute()) {
        $loginMessage = "✅ Registration successful! You can now log in.";
        $showLogin = true;
    } else {
        echo "<script>alert('❌ Error occurred during registration.'); window.history.back();</script>";
    }

    $stmt->close();
}

// Handle login
if (isset($_POST['login_btn'])) {
    $email = $conn->real_escape_string(trim($_POST['login_email']));
    $password = $_POST['login_pass'];

    $stmt = $conn->prepare("SELECT password FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows == 1) {
        $stmt->bind_result($hashed_pass);
        $stmt->fetch();

        if (password_verify($password, $hashed_pass)) {
            echo "<script>alert('✅ Login successful!'); window.location.href='farmerchoices.html';</script>";
            exit();
        } else {
            $loginMessage = "❌ Invalid password.";
        }
    } else {
        $loginMessage = "❌ No account found with that email.";
    }
    $stmt->close();
}

$conn->close();
?>




<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Glass Login & Signup</title>
  <style>
    * {
      margin: 0; padding: 0; box-sizing: border-box;
      font-family: "Segoe UI", sans-serif;
      font-weight: 600;
    }

    body {
      background: url("https://plus.unsplash.com/premium_photo-1661771014672-5cdd567329d4?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D") no-repeat center center/cover;
      height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      animation: fadeInBody 1s ease-in;
    }

    @keyframes fadeInBody {
      from { opacity: 0; }
      to { opacity: 1; }
    }

    .box {
      width: 350px;
      padding: 40px;
      background: rgba(255, 255, 255, 0.1);
      box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
      backdrop-filter: blur(10px);
      border-radius: 20px;
      border: 1px solid rgba(255, 255, 255, 0.2);
      color: #fff;
      animation: scaleFade 0.6s ease;
    }

    @keyframes scaleFade {
      from { opacity: 0; transform: scale(0.9); }
      to { opacity: 1; transform: scale(1); }
    }

    h2 {
      text-align: center;
      margin-bottom: 30px;
      font-size: 28px;
      color: aquamarine;
      font-weight: 700;
    }

    input {
      width: 100%;
      padding: 12px;
      margin: 10px 0;
      background: rgba(255, 255, 255, 0.2);
      border: none;
      border-radius: 10px;
      color: white;
      font-size: 16px;
      outline: none;
    }

    input::placeholder {
      color: #ddd;
    }

    input:focus {
      background: rgba(255, 255, 255, 0.3);
      border: 1px solid aquamarine;
    }

    button {
      width: 100%;
      padding: 12px;
      background-color: rgba(255, 255, 255, 0.3);
      color: white;
      font-size: 18px;
      border: none;
      border-radius: 10px;
      cursor: pointer;
      margin-top: 15px;
      font-weight: 700;
    }

    button:hover {
      background-color: rgba(255, 255, 255, 0.5);
      transform: scale(1.05);
    }

    p {
      text-align: center;
      margin-top: 20px;
    }

    p a {
      color: #fff;
      text-decoration: underline;
      cursor: pointer;
    }

    p a:hover {
      color: aquamarine;
    }

    .hidden {
      display: none;
    }

    .alert {
      background-color: #28a745;
      color: #fff;
      text-align: center;
      padding: 10px;
      border-radius: 5px;
      margin-bottom: 10px;
      font-size: 14px;
    }
  </style>
</head>
<body>
  <div class="box" id="loginBox">
    <h2>Welcome Back</h2>
    <?php if (!empty($loginMessage)): ?>
      <div class="alert"><?= $loginMessage ?></div>
    <?php endif; ?>
   <form method="POST" action="sign.php">
  <input type="email" name="login_email" placeholder="Email" required />
  <input type="password" name="login_pass" placeholder="Password" required />
  <button type="submit" name="login_btn">Login</button>
</form>

    <p>Don't have an account? <a onclick="showSignup()">Sign up</a></p>
  </div>

  <div class="box hidden" id="signupBox">
    <h2>Create Account</h2>
    <form method="POST" action="sign.php">
      <input type="text" placeholder="Full Name" name="user_name" required />
      <input type="email" placeholder="Email" name="user_email" required />
      <input type="password" placeholder="Password" name="user_pass" required />
      <input type="password" placeholder="Re-type Password" name="user_repass" required />
      <button type="submit" name="sb">Sign Up</button>
    </form>
    <p>Already have an account? <a onclick="showLogin()">Login</a></p>
  </div>

  <script>
    const loginBox = document.getElementById("loginBox");
    const signupBox = document.getElementById("signupBox");

    function showSignup() {
      loginBox.classList.add("hidden");
      signupBox.classList.remove("hidden");
    }

    function showLogin() {
      signupBox.classList.add("hidden");
      loginBox.classList.remove("hidden");
    }

      
    // Auto-switch to login if PHP set the success flag
    <?php if ($showLogin): ?>
      showLogin();
    <?php endif; ?>

  </script>
</body>
</html>